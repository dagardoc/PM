package com.example.contactoadapter

data class Contacto(
    val nombre: String,
    val telefono: String,
    val departamento: String
)