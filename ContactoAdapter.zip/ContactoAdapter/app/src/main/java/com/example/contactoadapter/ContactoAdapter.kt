package com.example.contactoadapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class ContactoAdapter(
    private val lista: List<Contacto>
) : RecyclerView.Adapter<ContactoAdapter.ContactoViewHolder>() {

    // -------------------------------
    //   VIEWHOLDER
    // -------------------------------
    class ContactoViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView), View.OnClickListener {

        private val tvNombre: TextView = itemView.findViewById(R.id.tvNombre)
        private val tvTelefono: TextView = itemView.findViewById(R.id.tvTelefono)
        private val tvDepartamento: TextView = itemView.findViewById(R.id.tvDepartamento)

        private var contactoActual: Contacto? = null

        init {
            itemView.setOnClickListener(this)
        }

        fun bind(contacto: Contacto) {
            contactoActual = contacto
            tvNombre.text = contacto.nombre
            tvTelefono.text = "📞 ${contacto.telefono}"
            tvDepartamento.text = "Depto: ${contacto.departamento}"
        }

        override fun onClick(v: View?) {
            val c = contactoActual ?: return
            Toast.makeText(
                v?.context,
                "Has pulsado a: ${c.nombre}",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    // -------------------------------
    //   ADAPTER
    // -------------------------------
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactoViewHolder {
        val vista = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_contacto, parent, false)
        return ContactoViewHolder(vista)
    }

    override fun onBindViewHolder(holder: ContactoViewHolder, position: Int) {
        holder.bind(lista[position])
    }

    override fun getItemCount(): Int = lista.size
}
