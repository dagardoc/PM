package com.example.tema2m;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ParkAdapter adapter;
    private List<Park> parkList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.ParksRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        parkList = new ArrayList<>();
        parkList.add(new Park("Parque Central", "Gran zona verde en el centro", R.drawable.ic_launcher_background));
        parkList.add(new Park("Parque del Río", "Perfecto para pasear junto al río", R.drawable.ic_launcher_background));
        parkList.add(new Park("Jardines del Sol", "Ideal para picnic y niños", R.drawable.ic_launcher_background));

        adapter = new ParkAdapter(parkList);
        recyclerView.setAdapter(adapter);
    }
}
