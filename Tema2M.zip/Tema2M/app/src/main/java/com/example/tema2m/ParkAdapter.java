package com.example.tema2m;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ParkAdapter extends RecyclerView.Adapter<ParkAdapter.ParkViewHolder> {

    private List<Park> parkList;

    public ParkAdapter(List<Park> parkList) {
        this.parkList = parkList;
    }

    @NonNull
    @Override
    public ParkViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.parque_card, parent, false);
        return new ParkViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ParkViewHolder holder, int position) {
        Park park = parkList.get(position);
        holder.parkName.setText(park.getName());
        holder.parkDesc.setText(park.getDescription());
        holder.parkImageView.setImageResource(park.getImageResId());
    }

    @Override
    public int getItemCount() {
        return parkList.size();
    }

    static class ParkViewHolder extends RecyclerView.ViewHolder {
        ImageView parkImageView;
        TextView parkName, parkDesc;

        public ParkViewHolder(@NonNull View itemView) {
            super(itemView);
            parkImageView = itemView.findViewById(R.id.parkImageView);
            parkName = itemView.findViewById(R.id.parkName);
            parkDesc = itemView.findViewById(R.id.parkDesc);
        }
    }
}
