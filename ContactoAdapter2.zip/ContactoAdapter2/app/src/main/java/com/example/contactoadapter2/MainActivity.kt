package com.example.contactoadapter2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.android.material.snackbar.Snackbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rvContactos = findViewById<RecyclerView>(R.id.rvContactos)
        rvContactos.layoutManager = LinearLayoutManager(this)

        // Datos de prueba (pueden ser los tuyos)
        val datos = listOf(
            Contacto("Juan", "600123123", "Ventas"),
            Contacto("Ana", "633112233", "Marketing"),
            Contacto("Pedro", "699887766", "Informática")
        )

        // Creamos el adapter pasando el callback
        val adapter = ContactoAdapter(datos) { contacto ->
            // Aquí decide la Activity qué pasa al clicar
            Snackbar.make(
                findViewById(R.id.root),
                "Contacto seleccionado: ${contacto.nombre}",
                Snackbar.LENGTH_SHORT
            ).show()
        }

        rvContactos.adapter = adapter
    }
}
