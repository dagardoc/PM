package com.example.contactoadapter2

data class Contacto(
    val nombre: String,
    val telefono: String,
    val departamento: String
)