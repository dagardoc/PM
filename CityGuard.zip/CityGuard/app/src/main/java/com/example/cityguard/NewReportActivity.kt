package com.example.cityguard

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import com.example.cityguard.model.Report
import com.google.android.material.snackbar.Snackbar
import java.util.*

class NewReportActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_report)

        val etAddress = findViewById<EditText>(R.id.et_address)
        val spinnerType = findViewById<Spinner>(R.id.spinner_type)
        val etDesc = findViewById<EditText>(R.id.et_description)
        val btnSave = findViewById<Button>(R.id.btn_save)

        // Tipos: tráfico, agua, alumbrado, basura
        val types = listOf("Tráfico", "Agua", "Alumbrado", "Basura")
        spinnerType.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, types)

        btnSave.setOnClickListener {
            val address = etAddress.text.toString().trim()
            val type = spinnerType.selectedItem?.toString() ?: "Otro"
            val desc = etDesc.text.toString().trim()

            if (address.isEmpty()) {
                etAddress.error = "Introduce dirección"
                return@setOnClickListener
            }

            val report = Report(
                id = UUID.randomUUID().toString(),
                address = address,
                type = type,
                description = desc
            )
            FakeDB.reports.add(report)

            Snackbar.make(btnSave, "Incidencia registrada", Snackbar.LENGTH_LONG)
                .setAction("Deshacer") {
                    FakeDB.reports.remove(report)
                }.show()

            // cerrar actividad para volver a Main/MyReports
            finish()
        }
    }
}
