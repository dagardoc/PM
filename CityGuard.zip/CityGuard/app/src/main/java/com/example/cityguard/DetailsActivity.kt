package com.example.cityguard

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import com.example.cityguard.dialog.ConfirmDialogFragment
import com.example.cityguard.util.NotificationHelper

class DetailsActivity : BaseActivity() {

    private var reportId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)

        val tvAddress = findViewById<TextView>(R.id.tv_address)
        val tvType = findViewById<TextView>(R.id.tv_type)
        val tvDesc = findViewById<TextView>(R.id.tv_description)
        val tvStatus = findViewById<TextView>(R.id.tv_status)
        val btnResolve = findViewById<Button>(R.id.btn_resolve)

        reportId = intent.getStringExtra("id")
        val report = FakeDB.reports.find { it.id == reportId }

        if (report != null) {
            tvAddress.text = report.address
            tvType.text = report.type
            tvDesc.text = report.description
            tvStatus.text = report.status
        }

        btnResolve.setOnClickListener {
            val dialog = ConfirmDialogFragment("Confirmar", "¿Marcar como resuelta?") {
                report?.let {
                    it.status = "Resuelta"
                    tvStatus.text = "Resuelta"
                    // actualizar lista en memoria (ya está actualizado)
                    // enviar notificación que abre esta misma Activity
                    NotificationHelper.sendUpdateNotification(this, it.id, it.address)
                }
            }
            dialog.show(supportFragmentManager, "confirm")
        }
    }
}
