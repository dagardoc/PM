package com.example.cityguard

import android.content.Intent
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.cityguard.adapter.ReportsAdapter

class MyReportsActivity : BaseActivity() {

    private lateinit var recycler: RecyclerView
    private lateinit var adapter: ReportsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_reports)

        recycler = findViewById(R.id.recycler_reports)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = ReportsAdapter(FakeDB.reports) { report ->
            val i = Intent(this, DetailsActivity::class.java)
            i.putExtra("id", report.id)
            startActivity(i)
        }
        recycler.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        // refrescar lista si hay cambios
        adapter.notifyDataSetChanged()
    }
}
