package com.example.cityguard

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.cityguard.util.NotificationHelper

class MainActivity : BaseActivity() {

    private val NOTIF_PERMISSION_CODE = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Crear canal de notificaciones
        NotificationHelper.createChannel(this)

        // Pedir permiso para notificaciones si Android 13+
        requestNotificationPermissionIfNeeded()

        val btnNew = findViewById<Button>(R.id.btn_new)
        val btnMy = findViewById<Button>(R.id.btn_my_reports)

        btnNew.setOnClickListener {
            startActivity(android.content.Intent(this, NewReportActivity::class.java))
        }

        btnMy.setOnClickListener {
            startActivity(android.content.Intent(this, MyReportsActivity::class.java))
        }

        // --- EJEMPLO opcional de notificación de prueba ---
        // Solo para testear que no da errores:
        // NotificationHelper.sendTestNotification(this)
    }

    // Función que pide el permiso POST_NOTIFICATIONS si es Android 13+
    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    NOTIF_PERMISSION_CODE
                )
            }
        }
    }

    // Manejo de la respuesta del usuario
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == NOTIF_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permiso concedido
            } else {
                // Permiso denegado, las notificaciones no funcionarán
            }
        }
    }
}
