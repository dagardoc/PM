package com.example.cityguard.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.cityguard.DetailsActivity
import com.example.cityguard.R

object NotificationHelper {
    private const val CHANNEL_ID = "cityguard_channel"
    private const val CHANNEL_NAME = "Actualizaciones CityGuard"

    /**
     * Crea el canal de notificaciones (Android 8+)
     */
    fun createChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            )
            channel.description = "Notificaciones sobre incidencias actualizadas"
            val manager = ctx.getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    /**
     * Envía una notificación de actualización de incidencia
     * Solo se ejecuta si el permiso POST_NOTIFICATIONS está concedido (Android 13+)
     */
    fun sendUpdateNotification(ctx: Context, reportId: String, address: String) {

        // Verificar permiso Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    ctx,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                // No tiene permiso, no enviar notificación
                return
            }
        }

        // Intent que abre DetailsActivity
        val intent = Intent(ctx, DetailsActivity::class.java).apply {
            putExtra("id", reportId)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        else
            PendingIntent.FLAG_UPDATE_CURRENT

        val pending = PendingIntent.getActivity(ctx, reportId.hashCode(), intent, flags)

        val builder = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification) // asegúrate de tener este drawable
            .setContentTitle("Se ha actualizado una incidencia")
            .setContentText(address)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pending)

        val notifId = reportId.hashCode()

        NotificationManagerCompat.from(ctx).notify(notifId, builder.build())
    }

    /**
     * Función de prueba opcional para enviar notificación de ejemplo
     */
    fun sendTestNotification(ctx: Context) {
        sendUpdateNotification(ctx, "test123", "Calle de prueba 1")
    }
}
