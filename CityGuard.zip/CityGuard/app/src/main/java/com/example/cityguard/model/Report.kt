package com.example.cityguard.model

data class Report(
    val id: String,
    var address: String,
    var type: String,
    var description: String,
    var status: String = "Pendiente"
)
