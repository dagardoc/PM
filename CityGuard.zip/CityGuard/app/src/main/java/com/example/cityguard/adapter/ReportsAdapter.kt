package com.example.cityguard.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.cityguard.R
import com.example.cityguard.model.Report

class ReportsAdapter(
    private val items: List<Report>,
    private val onClick: (Report) -> Unit
) : RecyclerView.Adapter<ReportsAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val icon: ImageView = view.findViewById(R.id.card_icon)
        private val address: TextView = view.findViewById(R.id.card_address)
        private val status: TextView = view.findViewById(R.id.card_status)

        fun bind(r: Report) {
            address.text = r.address
            status.text = r.status

            // inside bind(r: Report)
            val typeNormalized = r.type?.trim()?.lowercase() ?: ""
            val drawable = when {
                typeNormalized.contains("tráf".lowercase()) || typeNormalized.contains("traf") -> R.drawable.ic_trafico
                typeNormalized.contains("agua") -> R.drawable.ic_agua
                typeNormalized.contains("alumbrado") -> R.drawable.ic_alumbrado
                typeNormalized.contains("basur") || typeNormalized.contains("basura") -> R.drawable.ic_basura
                else -> R.drawable.ic_trafico // fallback
            }
            icon.setImageResource(drawable)

            itemView.setOnClickListener { onClick(r) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.card_report, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(items[position])
    }
}
