package com.example.cityguard

import com.example.cityguard.model.Report
import java.util.*

object FakeDB {
    val reports = mutableListOf<Report>()

    // datos de ejemplo
    init {
        reports.add(Report(UUID.randomUUID().toString(), "Calle Mayor 1", "Tráfico", "Coche abandonado", "Pendiente"))
        reports.add(Report(UUID.randomUUID().toString(), "Av. del Río 12", "Agua", "Fuga en la tubería", "Pendiente"))
    }
}
