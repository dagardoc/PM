package com.example.minitareafinal

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import androidx.fragment.app.DialogFragment

class ConfirmDialog : DialogFragment() {

    interface ConfirmDialogListener {
        fun onDialogPositiveClick()
        fun onDialogNegativeClick()
    }

    private lateinit var listener: ConfirmDialogListener

    override fun onAttach(context: Context) {
        super.onAttach(context)
        listener = context as ConfirmDialogListener
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return AlertDialog.Builder(requireContext())
            .setTitle("Confirmación")
            .setMessage("¿Deseas guardar los datos de esta planta?")
            .setPositiveButton("Aceptar") { _, _ -> listener.onDialogPositiveClick() }
            .setNegativeButton("Cancelar") { _, _ -> listener.onDialogNegativeClick() }
            .create()
    }
}
