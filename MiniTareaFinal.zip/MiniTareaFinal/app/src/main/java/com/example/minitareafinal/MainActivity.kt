package com.example.minitareafinal

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.android.material.snackbar.Snackbar

class MainActivity : BaseMenuActivity(), ConfirmDialog.ConfirmDialogListener {

    private val CHANNEL_ID = "smartgarden_channel"
    private val NOTIF_ID = 1

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) mostrarNotificacion()
            else Toast.makeText(this, "Permiso denegado", Toast.LENGTH_SHORT).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etNombre = findViewById<EditText>(R.id.editNombre)
        val btnGuardar = findViewById<Button>(R.id.btnGuardar)
        val btnAviso = findViewById<Button>(R.id.btnAviso)
        val btnNotificacion = findViewById<Button>(R.id.btnNotificacion)
        val btnCerrarSesion = findViewById<Button>(R.id.btnCerrarSesion)

        crearCanal()

        // 🔹 Botón Guardar → abre el diálogo de confirmación
        btnGuardar.setOnClickListener {
            val dialog = ConfirmDialog()
            dialog.show(supportFragmentManager, "ConfirmDialog")
        }

        // 🔹 Botón Aviso → Snackbar con acción “Deshacer”
        btnAviso.setOnClickListener {
            Snackbar.make(it, "Planta guardada correctamente 🌿", Snackbar.LENGTH_LONG)
                .setAction("Deshacer") {
                    Toast.makeText(this, "Acción cancelada", Toast.LENGTH_SHORT).show()
                }.show()
        }

        // 🔹 Botón Notificación
        btnNotificacion.setOnClickListener {
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                mostrarNotificacion()
            }
        }

        // 🔹 Botón Cerrar sesión → Snackbar
        btnCerrarSesion.setOnClickListener {
            Snackbar.make(it, "Sesión cerrada correctamente.", Snackbar.LENGTH_LONG).show()
        }
    }

    // 🔸 Crear canal para notificaciones (Android 8+)
    private fun crearCanal() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Canal Smart Garden"
            val descriptionText = "Canal para notificaciones del jardín"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    // 🔸 Mostrar notificación
    private fun mostrarNotificacion() {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Smart Garden")
            .setContentText("Riego automático activado a las 20:00 🌧️")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        with(NotificationManagerCompat.from(this)) {
            notify(NOTIF_ID, builder.build())
        }
    }

    // Callbacks del diálogo
    override fun onDialogPositiveClick() {
        Snackbar.make(findViewById(android.R.id.content), "Datos guardados", Snackbar.LENGTH_LONG)
            .show()
    }

    override fun onDialogNegativeClick() {
        Toast.makeText(this, "Operación cancelada", Toast.LENGTH_SHORT).show()
    }
}
