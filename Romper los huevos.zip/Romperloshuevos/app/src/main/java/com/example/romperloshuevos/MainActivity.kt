package com.example.romperloshuevos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.romperloshuevos.ui.theme.RomperLosHuevosTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RomperLosHuevosTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = "Android",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    // ✅ Ahora taps se guarda incluso al rotar o recrear la actividad
    var taps by rememberSaveable { mutableStateOf(0) }

    // Metas
    val crackGoal = 10
    val hatchGoal = 20

    // Emoji según taps
    val emoji = when {
        taps >= hatchGoal -> "🐣"
        taps >= crackGoal -> "💥🥚"
        else -> "🥚"
    }

    // Mensaje según taps
    val message = when {
        taps >= hatchGoal -> "¡Ha nacido!"
        taps >= crackGoal -> "¡Se agrieta!"
        else -> "Toca…"
    }

    // Barra de progreso
    val rawProgress = taps.toFloat() / hatchGoal.toFloat()
    val progress = rawProgress.coerceIn(0f, 1f)
    val percent = (progress * 100).toInt()

    // Animación de rebote
    var isBouncing by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isBouncing) 1.2f else 1f,
        label = "eggScale"
    )
    val scope = rememberCoroutineScope()

    Column(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Emoji con rebote y click desactivado si ya nació 🐣
        Text(
            text = emoji,
            fontSize = 120.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .scale(scale)
                .then(
                    if (taps < hatchGoal) {
                        Modifier.clickable {
                            taps++
                            isBouncing = true
                            scope.launch {
                                delay(150)
                                isBouncing = false
                            }
                        }
                    } else {
                        Modifier // sin click cuando ha nacido
                    }
                )
        )

        // Mensaje dinámico
        Text(
            text = message,
            fontSize = 28.sp,
            modifier = Modifier.padding(top = 16.dp)
        )

        // Contador
        Text(
            text = "Taps: $taps",
            fontSize = 22.sp,
            modifier = Modifier.padding(top = 8.dp)
        )

        // Barra de progreso
        LinearProgressIndicator(
            progress = progress,
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .padding(top = 16.dp)
        )

        // Porcentaje
        Text(
            text = "$percent%",
            fontSize = 18.sp,
            modifier = Modifier.padding(top = 8.dp)
        )

        // Botones Reset y +5
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 24.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            // Reset
            Button(onClick = { taps = 0 }) {
                Text("Reset")
            }

            // Boost +5
            Button(
                onClick = {
                    taps = (taps + 5).coerceAtMost(hatchGoal)
                }
            ) {
                Text("+5")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    RomperLosHuevosTheme {
        Greeting("Android")
    }
}
